# Coquetta Beauty — Vercel Deploy Notes

1. Framework Preset: **Next.js**
2. Build Command: `next build`
3. Output Directory: **.next** (default)
4. Environment variables: none required for the starter.
5. If you later add remote images, update `next.config.mjs` `images.remotePatterns`.
